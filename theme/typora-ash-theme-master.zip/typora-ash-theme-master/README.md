# Ash

A nice dark theme. 

Require macOS ≥ 10.12 (or ≥ Safari 9.1) or Windows/Linux. And Typora ≥ v0.9.9.10.6/v0.9.36.

![Snip20170826_6](Snip20170826_6.png)

![Snip20170826_7](Snip20170826_7.png)

![Snip20170826_8](Snip20170826_8.png)



