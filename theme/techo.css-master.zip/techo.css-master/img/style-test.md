# h1

## h2

### h3

#### h4

##### h5

###### h6

![lun-origin](lun-origin.jpg)

* [ ] lfkdsk
* [x] lfkdsk


1. lfkdsk
2. lfkdsk
   - lfkdsk
     - [x] task down




``` html
<html>
    <body>
        <h1>
            Head 1
        </h1>
    </body>
</html>
```

**strong**

$$ X^2 $$

$$ H_2~O $$

[Link]()

_literal_

~~delete~~

*literal*

`inline-code`

Name | Lunch order | Spicy      | Owes
------- | ---------------- | ---------- | ---------:
Joan  | saag paneer | medium | $11
Sally  | vindaloo        | mild       | $14
Erin   | lamb madras | HOT      | $5

There are **multiple syntax highlighting themes** to choose from. Here's one of them:

```javascript
// All the code you will ever need
var hw = "Hello World!"
alert(hw);
```

My math is so rusty that I barely remember the _quadratic equation_:
$-b \pm \sqrt{b^2 - 4ac} \over 2a$
> Blockquotes are very handy in email to emulate reply text.
> This line is part of the same quote.

Quote break.

> This is a very long line that will still be quoted properly when it wraps. Oh boy let's keep writing to make sure this is long enough to actually wrap for everyone. Oh, you can *put* **Markdown** into a blockquote. 


